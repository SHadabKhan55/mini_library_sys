import express from "express"
import { isLogin, login, logout, register } from "../controller/auth.controller.js"
import checkUserLogin from "../middleware/checkLogin.js"
const router = express.Router()

router.post("/register",register)
router.post("/login",login)
router.post("/logout",logout)

router.get("/check-login", checkUserLogin, isLogin);

export default router

