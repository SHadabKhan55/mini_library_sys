import { createBrowserRouter, Router, RouterProvider } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import ProtectRoute from './components/ProtectRoute'
import Dashbaord from './pages/librarian/Dashbaord'


const App = () => {
  const router = createBrowserRouter([
    {
      path:"/login",
      element:<Login/>
    },
    {
      path:"/register",
      element:<Register/>
    },
      {
      path:"/lib-dashboard",
      element:(
        <ProtectRoute allowedRole={["student","librarian"]}>
        <Dashbaord/>
        </ProtectRoute>
      )
    },
    
  ])
  return (
    <div>
      <RouterProvider router={router}/>
    </div>
  )
}

export default App